import 'package:flutter/material.dart';

class FirstPage extends StatefulWidget {
  FirstPage({Key key}) : super(key: key);

  @override
  _FirstPageState createState() => _FirstPageState();
}

class _FirstPageState extends State<FirstPage> {
  int counter = 0;
  int counter2 = 100;
  void increamentCounter() {
    setState(() {
      counter++;
    });
  }

  void decreamentCounter() {
    setState(() {
      counter2--;
    });
  }

  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;

    return Scaffold(
      persistentFooterButtons: [
        Container(
          height: 40,
          width: 40,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: LinearGradient(colors: [Colors.grey, Colors.blueGrey]),
          ),
          child: IconButton(
              icon: Icon(
                Icons.add,
                color: Colors.black,
              ),
              onPressed: () {
                increamentCounter();
              }),
        ),
        Container(
          height: 40,
          width: 40,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: LinearGradient(colors: [Colors.grey, Colors.blueGrey]),
          ),
          child: IconButton(
              icon: Icon(
                Icons.exposure_minus_1,
                color: Colors.black,
              ),
              onPressed: () {
                decreamentCounter();
              }),
        ),
      ],
      backgroundColor: Color.fromRGBO(184, 204, 197, 1),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      floatingActionButton: FloatingActionButton(
        elevation: 20,
        backgroundColor: Colors.grey[400],
        onPressed: () {
          increamentCounter();
          decreamentCounter();
        },
        child: Text(
          'Next',
          style: TextStyle(color: Colors.black),
        ),
        //   child: Icon(
        //     Icons.add,
        //     color: Colors.black,size: 30,
        // ),
      ),
      appBar: AppBar(
        backgroundColor: Color.fromRGBO(184, 204, 197, 1),
        leading: Icon(
          Icons.arrow_back,
          color: Colors.black,
        ),
        title: Text(
          'ASSIGNMENT',
          style: TextStyle(color: Colors.black),
        ),
        centerTitle: true,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Container(
          margin: EdgeInsets.only(top: 20),
          width: width,
          height: height,
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [Colors.grey, Colors.blueGrey]),
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20), topRight: Radius.circular(20)),
          ),
          alignment: Alignment.center,
          child: Column(
            children: [
              Container(
                margin: EdgeInsets.only(top: 20, left: 30),
                alignment: Alignment.center,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    textCont('K'),
                    textCont('H'),
                    textCont('A'),
                    textCont('D'),
                    textCont('I'),
                    textCont('J'),
                    textCont('A'),
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.only(left: 70),
                alignment: Alignment.center,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    textCont('M'),
                    textCont('U'),
                    textCont('S'),
                    textCont('T'),
                    textCont('A'),
                    textCont('F'),
                    textCont('A'),
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.only(top: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    assCont('Assignment'),
                    assCont('1st Week'),
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.only(top: 10),
                child: contt3(
                    ' Widget',
                    'In flutter, Widget is a way to declare and construct UI. For example, row,column,container etc. ',
                    400),
              ),
              Container(
                margin: EdgeInsets.only(top: 10),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    contt3(
                        'Stateful Widget',
                        'A stateful widget can redraw itself multiple times, while the app is running which means its state is mutable.For example, when a button is pressed, the state of the widget is changed.',
                        180),
                    contt3(
                        'Stateless Widget',
                        'A stateless widget can not change their state during the runtime of an app which means it can not redraw its self while the app is running.',
                        180),
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.only(top: 20,left: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [buttoncont('$counter'), buttoncont('$counter2')],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  buttoncont(String text) {
    return Container(
      margin: EdgeInsets.only(right: 10,),
      alignment: Alignment.center,
      height: 40,
      width: 40,
      decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white),
      child: Text('$text'),
    );
  }

  contt3(String title, String text, double width) {
    return Container(
      padding: EdgeInsets.all(10),
      width: width,
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [
          Colors.grey[400],
          Colors.grey[300],
        ]),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            alignment: Alignment.topLeft,
            padding: EdgeInsets.all(5),
            child: Text(
              '$title',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
          ),
          Container(
            alignment: Alignment.center,
            padding: EdgeInsets.all(2),
            child: Text(
              '$text',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.normal),
            ),
          )
        ],
      ),
    );
  }

  assCont(String text) {
    return Container(
      alignment: Alignment.center,
      padding: EdgeInsets.all(5),
      height: 40,
      width: 150,
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [
          Colors.lightBlueAccent,
          Colors.grey[300],
          Colors.green[200],
          Colors.orangeAccent,
        ]),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Text(
        '$text',
        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
      ),
    );
  }

  textCont(String text) {
    return Container(
      margin: EdgeInsets.only(top: 20),
      alignment: Alignment.center,
      padding: EdgeInsets.all(5),
      height: 40,
      width: 40,
      decoration: BoxDecoration(
          shape: BoxShape.circle,
          // borderRadius: BorderRadius.circular(10),
          gradient: LinearGradient(colors: [
            Colors.deepPurple,
            Colors.lightBlueAccent,
            Colors.pink[200],
            Colors.greenAccent,
            Colors.orangeAccent,
            Colors.red
          ])),
      child: Text('$text',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
    );
  }
}
