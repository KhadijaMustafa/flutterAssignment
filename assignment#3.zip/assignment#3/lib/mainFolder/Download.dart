import 'package:flutter/material.dart';
class Download extends StatefulWidget {
  Download({Key key}) : super(key: key);

  @override
  _DownloadState createState() => _DownloadState();
}

class _DownloadState extends State<Download> {
  List<Map> download=[
    {'image':'assets/image.png','title':'Narcos','subtitle':'4 Episode|502GB'},
    {'image':'assets/Image 28.png','title':'Alita','subtitle':'4 Episode|502GB'},
    {'image':'assets/Image 30.png','title':'Gotham','subtitle':'4 Episode|502GB'},
    {'image':'assets/Image 33.png','title':'Anita','subtitle':'4 Episode|502GB'},
       {'image':'assets/Image 26.png','title':'Narcos','subtitle':'4 Episode|502GB'},
    {'image':'assets/Image 28.png','title':'Alita','subtitle':'4 Episode|502GB'},
    {'image':'assets/Image 30.png','title':'Gotham','subtitle':'4 Episode|502GB'},
    {'image':'assets/Image 33.png','title':'Anita','subtitle':'4 Episode|502GB'},
  ];
  @override
  Widget build(BuildContext context) {
    double width=MediaQuery.of(context).size.width;
    double height=MediaQuery.of(context).size.height;

    return Scaffold(
       backgroundColor: Color.fromRGBO(99, 29, 28, 1),
      body: Container(
        child: SingleChildScrollView(
          child: Column(
            children: [
              Container(
              margin: EdgeInsets.only(top:20),
                width: width,
                height: height,
                child: ListView.builder(
                  itemCount: download.length,
                  scrollDirection: Axis.vertical,
                  itemBuilder: (BuildContext context, int index) {
                    var item=download[index];
                  return downloadCont(item['image'], item['title'], item['subtitle']);
                 },
                ),

              )
            ],
          ),
        ),
      ),
       
    );
  }
  downloadCont(String image, String title, String subtitle){
    return Container(
      margin: EdgeInsets.only(top:10,right:10,left:20),
      child: Row(
        children: [
          Container(
        
            height: 100,
            width: 200,
             decoration: BoxDecoration(
                image: DecorationImage(image: AssetImage('$image'),fit: BoxFit.cover),
              
            )
            // child: Image.asset('$image'),
          ),
          Container(
           margin: EdgeInsets.only(left:20),
            child: Column(
         crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  child: Text('$title',style: TextStyle(
                    color:Colors.pink[200],
                    fontSize: 16
                  ),),
                ),
                Container(
                margin: EdgeInsets.only(top:7),
                  child: Text('$subtitle',style: TextStyle(
                    color:Colors.pink[200],
                    fontSize: 14
                  ),),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}