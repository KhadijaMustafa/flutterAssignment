import 'package:first_app/mainFolder/Download.dart';
import 'package:first_app/mainFolder/Home.dart';
import 'package:first_app/mainFolder/Profile.dart';
import 'package:first_app/mainFolder/Search.dart';
import 'package:flutter/material.dart';
class MainScreen extends StatefulWidget {
  MainScreen({Key key}) : super(key: key);

  @override
  _MainScreenState createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
   int selectedIndex = 3;
  bool show;
  List<Widget> widgets = [ Home(),Search(), Download(), Profile()];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: widgets.elementAt(selectedIndex),
      bottomNavigationBar: BottomAppBar(
        color: Color.fromRGBO(99, 29, 28, 1),
         
        child: Container(
          
          decoration: BoxDecoration(
            color: Color.fromRGBO(79, 11, 27, 1),
              borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(35),
                    topRight: Radius.circular(35),
                    
                  ),
                 
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
             
              
              IconButton(
                  icon: Icon(
                    Icons.home,
                    color: selectedIndex == 0 ? Colors.pink[200] : Colors.grey,
                  ),
                  onPressed: () {
                    changeIndex(0);
                  }),
              IconButton(
                  icon: Icon(
                    Icons.search,
                    color: selectedIndex == 1 ? Colors.pink[200] : Colors.grey,
                  ),
                  onPressed: () {
                    changeIndex(1);
                  }),
              IconButton(
                  icon: Icon(
                    Icons.download_rounded,
                    color: selectedIndex == 2 ? Colors.pink[200] : Colors.grey,
                  ),
                  onPressed: () {
                    changeIndex(2);
                  }),
                   IconButton(
                  icon: Icon(
                    Icons.person,
                    color: selectedIndex == 3 ? Colors.pink[200] : Colors.grey,
                  ),
                  onPressed: () {
                    changeIndex(3);
                  }),
            ],
          ),
        ),
      ),
       
    );
  }
  changeIndex(int index) {
    setState(() {
      selectedIndex = index;
    });
  }
}