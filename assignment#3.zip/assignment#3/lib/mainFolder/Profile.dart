import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
class Profile extends StatefulWidget {
  Profile({Key key}) : super(key: key);

  @override
  _ProfileState createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  @override
  Widget build(BuildContext context) {
    double width=MediaQuery.of(context).size.width;
    return Scaffold(
      backgroundColor: Color.fromRGBO(99, 29, 28, 1),
       body: Container(
        child: SingleChildScrollView(
          child: Column(
            children: [
              Container(
                child: Column(
                  children: [
                    Container(
                    margin: EdgeInsets.only(top:50),
                      width: width,
                      // height: 130,
                      child: Column(
                        children: [
                          Container(
                              height: 100,
                              width: 100,
                              margin: EdgeInsets.only(right: 20),
                              child: CircleAvatar(
                                backgroundImage:
                                    AssetImage('assets/image.png'),
                                backgroundColor: Colors.white,
                              )),
                              Container(
                                margin: EdgeInsets.only(top:10),
                                child: Text('Tasun Prasad',style: TextStyle(color:Colors.white,fontSize: 18),),
                              ),
                               Container(
                                child: Text('Premium',style: TextStyle(color:Colors.orange,fontSize: 16),),
                              ),
                        ],
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.only(left:30,right:10,top:10),
                      child: Column(
                        children: [
                          menuCont('account', Colors.pink[200],
                              Icons.person),
                          InkWell(
                            onTap: () {
                             
                            },
                            child: menuCont(
                                'Notification',
                               Colors.pink[200],
                                Icons.add),
                          ),
                          InkWell(
                            onTap: () {
                          
                            },
                            child: menuCont(
                                'Setting',
                                Colors.pink[200],
                                Icons.person_add_alt),
                          ),
                          InkWell(
                            onTap: () {},
                            child: menuCont(
                                'Help',
                                Colors.pink[200],
                                Icons.touch_app),
                          ),
                          InkWell(
                            onTap: () {},
                            child: menuCont(
                                'Logout',
                              Colors.pink[200],
                                Icons.lock),
                          ),
                        
                        
                       
                       
                        ],
                      ),
                    ),
                 
                   
                  ],
                ),
              ),
            
            ],
          ),
        ),
      ),
     
    );
  }
   menuCont(String text, Color color, IconData icon) {
    return Container(
    child: Column(
      children: [
        Container(
            child: Row(
        children: [
          Container(
            margin: EdgeInsets.only(left: 10),
            height: 65,
            child: Icon(
              icon,
              color: color,
            ),
          ),
          Container(
            margin: EdgeInsets.only(left: 15),
            height: 20,
            child: Text(
              '$text',
              style: TextStyle(
                  color: color, fontSize: 16, fontWeight: FontWeight.normal),
            ),
          )
        ],
      ),
        ),
        Divider(
          height: 0.5,
          thickness: 0.5,
          color: Colors.pink[200],
          endIndent: 10,
          indent: 10,
        )
      ],
    ),
    );
  }
}