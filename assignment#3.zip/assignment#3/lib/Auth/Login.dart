import 'package:first_app/mainFolder/MainScreen.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:first_app/Assignment2/Navigation.dart' as navigator;

class Login extends StatefulWidget {
  Login({Key key}) : super(key: key);

  @override
  _LoginState createState() => _LoginState();
}

class _LoginState extends State<Login> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromRGBO(99, 29, 28, 1),
           appBar: AppBar(
             elevation: 0,
             backgroundColor: Color.fromRGBO(99, 29, 28, 1),
             title: Text('Back'),
             leading: IconButton(icon: Icon(Icons.arrow_back), onPressed: (){}),
           ),
           body: Container(
             child: SingleChildScrollView(
               child:Column(
                 children: [
                   Container(
                     child: Column(
                       children: [
                        Container(
                          child:  Image.asset('assets/log.PNG'),
                        ),
                        Container(
                          child: textCont('Movie download', 18, FontWeight.w300)),
                        
                       ],
                     ),
                   ),
                   Container(
                     margin: EdgeInsets.only(left:20,right:20,top:20),
                     child: Column(
                     
                       children: [
                         tFieldCont('Email', 'email here'),
                         tFieldCont('Password', 'Enter password'),
                         InkWell(
                onTap: () {navigator.push(context, MainScreen());},
                child: Container(
                  margin: EdgeInsets.only(top:10,left: 20),
                    alignment: Alignment.center,
                    height: 50,
                    decoration: BoxDecoration(
                     color: Colors.orange,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child:textCont('Login', 16, FontWeight.bold)),
              ),
                       ],
                     ),
                   ),
                   Container(
                      margin: EdgeInsets.only(top:30,),
                     child: Row(
                       mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                       children: [
                         Container(
                           width: 70,
                           height: 1,
                           color: Colors.white
                         ),
                         Container(
                           child: textCont('Social logins', 15, FontWeight.normal),
                         ),
                          Container(
                           width: 70,
                           height: 1,
                           color: Colors.white
                         ),
                       ],
                     ),
                   ),
                   Container(
                     margin: EdgeInsets.only(top:20,bottom:20),
                     child: Row(
                     mainAxisAlignment: MainAxisAlignment.center,
                       children: [
                       iconcnt(FontAwesomeIcons.facebook),
                        iconcnt(FontAwesomeIcons.google),
                       ],
                     ),
                   ),
                   textCont('Dont have an account', 16, FontWeight.normal),
                   textCont('Register', 16, FontWeight.bold),
                 ],
               )
             ),
           ),
    );
  }
  iconcnt(IconData icon){
    return Container(
      margin: EdgeInsets.only(left:15,),
      width: 50,
      height: 50,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(50),
        color:Colors.orange,
      ),
      child: Icon(icon,color:Color.fromRGBO(99, 29, 28, 1) ,),
    );
  }
  textCont(String text,double fontsize,FontWeight fontWeight){
    return Container(
      child: Text('$text',style:TextStyle(color:Colors.white,fontSize: fontsize,fontWeight: fontWeight)),
    );
  }
   tFieldCont(String text, String hint){
    return Container(
      margin: EdgeInsets.only(top:10),
      alignment: Alignment.topLeft,
      padding: EdgeInsets.only(left:20),
      height: 90,
      
     child: Column(
         mainAxisAlignment: MainAxisAlignment.start,
                       crossAxisAlignment: CrossAxisAlignment.start,
       children: [
         Container(child:Text('$text',style: TextStyle(color:Colors.white),)),
         Container(
           height: 50,
           margin: EdgeInsets.only(top:10),
           padding: EdgeInsets.only(left:20),
           decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
       
        color: Colors.white
      ),
            child: TextFormField(
        decoration: InputDecoration(border: InputBorder.none
        , hintText: '$hint',hintStyle: TextStyle(color:Colors.grey,fontSize: 14,fontWeight: FontWeight.w300)),


      ),
         )
       ],
     ),
    );
  }
}