import 'package:flutter/material.dart';
class Thirdp extends StatefulWidget {
  Thirdp({Key key}) : super(key: key);

  @override
  _ThirdpState createState() => _ThirdpState();
}

class _ThirdpState extends State<Thirdp> {
  @override
  Widget build(BuildContext context) {
    double width=MediaQuery.of(context).size.width;
    return Scaffold(
      backgroundColor: Colors.purple[800],
      body: Container(
        alignment: Alignment.center,
        width: width,
        child: Column(
          children: [
            Container(
              margin: EdgeInsets.only(top:80,left:10,right:10),
             
              child: Column(
                children: [
                  Card(
                    child: Container(
                      alignment: Alignment.center,
                      height: 400,
                       padding: EdgeInsets.all(20),
                      child:Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        
                        children: [
                          Container(
                            child: Text('Congratulations, Kishure!'),
                          ),
                          Container(
                            margin:EdgeInsets.only(top:10),
                            child:Row(
                             
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                 Container(
                            child: Text('You won',style: TextStyle(color:Colors.black,fontWeight: FontWeight.bold,fontSize: 18)),
                          ),
                           Container(
                            child: Text("150",style: TextStyle(color:Colors.orange,fontWeight: FontWeight.bold,fontSize: 18),),
                          ),
                              ],
                            )
                          ),
                          buttoncont('How to play?',Colors.white,Colors.purple[700],150,30),
                        ],
                      ),
                    ),
                  )
                ],
              ),
            ),
              InkWell(
                    onTap:() {},
                    child:  buttoncont('Continue Playing',Colors.black,Colors.white,200,40),
                    
                  )
          ],
        ),
      ),
       
    );
  }
   buttoncont(String text, Color color, Color bgcolor, double width,double height) {
    return Container(

      margin: EdgeInsets.only(top:20),
      alignment: Alignment.center,
      height: height,
      width: width,
      decoration: BoxDecoration( color: bgcolor,borderRadius: BorderRadius.circular(20)),
      child: Text('$text',style: TextStyle(color:color,fontWeight: FontWeight.bold),),
    );
  }
}