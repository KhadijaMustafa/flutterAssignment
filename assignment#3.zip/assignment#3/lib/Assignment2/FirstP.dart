import 'package:first_app/Assignment2/SecondP.dart';
import 'package:first_app/Assignment2/ThirdP.dart';
import 'package:flutter/material.dart';
import 'package:first_app/Assignment2/Navigation.dart' as navigator;
class FirstP extends StatefulWidget {
  FirstP({Key key}) : super(key: key);

  @override
  _FirstPState createState() => _FirstPState();
}

class _FirstPState extends State<FirstP> {
  @override
  Widget build(BuildContext context) {
    double width=MediaQuery.of(context).size.width;
    return Scaffold(
      body: Container(
        width: width,
        color: Colors.purple[800],
        child:Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Center(
              child: Container(
                 margin: EdgeInsets.only(top:200),
                alignment: Alignment.center,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  // mainAxisAlignment: MainAxisAlignment.start,

                  children: [
                    Text('TRIVIA ',style: TextStyle(color:Colors.white,fontWeight: FontWeight.w900,fontSize: 30),),
                    Text(' WARS',style: TextStyle(color:Colors.white,fontWeight: FontWeight.w900,fontSize: 30),),
                  ],
                ),
              ),
            ),
            Container(
              margin: EdgeInsets.only(top:200),
              child:Column(
               
                children: [
                  InkWell(
                    onTap:() =>navigator.push(context, SecondP()),
                    child:  buttoncont('Start Playing',Colors.black,Colors.white,200,40),
                    
                  )
                  ,
           
             InkWell(
               onTap: ()=>navigator.push(context, Thirdp()),
               child:   buttoncont('How to play?',Colors.white,Colors.purple[900],150,30),
             )

                ],
              )
            )
           
          ],
        )
      ),
       
    );
  }
  buttoncont(String text, Color color, Color bgcolor, double width,double height) {
    return Container(

      margin: EdgeInsets.only(top:20),
      alignment: Alignment.center,
      height: height,
      width: width,
      decoration: BoxDecoration( color: bgcolor,borderRadius: BorderRadius.circular(20)),
      child: Text('$text',style: TextStyle(color:color,fontWeight: FontWeight.bold),),
    );
  }
}