import 'package:flutter/material.dart';
push(BuildContext context, Widget screen){
  var route=MaterialPageRoute(builder: (context)=>screen);
  Navigator.push(context, route);}
