import 'package:flutter/material.dart';
import 'package:sleek_circular_slider/sleek_circular_slider.dart';

class SecondP extends StatefulWidget {
  SecondP({Key key}) : super(key: key);

  @override
  _SecondPState createState() => _SecondPState();
}

class _SecondPState extends State<SecondP> {
  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    return Scaffold(
      backgroundColor: Colors.purple[800],
      body: Container(
        width: width,
        margin: EdgeInsets.only(top: 70),
        padding: EdgeInsets.only(left: 20, right: 20),
        child: SingleChildScrollView(
          child: Column(
            children: [
              Card(
                  elevation: 30,
                  child: Column(
                    children: [
                      Container(
                        padding: EdgeInsets.all(10),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            uCont(Icons.add, '4/10', Colors.transparent,
                                Colors.black, Colors.black),
                            uCont(Icons.add, '4/10', Colors.orange,
                                Colors.white, Colors.white),
                            uCont(Icons.add, '4/10', Colors.transparent,
                                Colors.black, Colors.black),
                          ],
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.only(top:10),
                        height: 60,
                        child: SleekCircularSlider(
                          appearance: CircularSliderAppearance(
                              size: 50,
                              counterClockwise: true,
                              // spinnerMode: false,
                              // spinnerDuration: 5,
                              customWidths: CustomSliderWidths(
                                progressBarWidth: 5,
                              )),
                          min: 2,
                          max: 10,
                          initialValue: 6,
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.only(top: 20, left: 20, right: 20),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            textCont(
                                'Technology', Colors.grey, FontWeight.w500, 16),
                            textCont(
                                'When was the first product launched by apple?',
                                Colors.black,
                                FontWeight.bold,
                                22),
                          ],
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.only(top: 20, bottom: 30),
                        child: Column(
                          children: [
                            optionCont('iPhone', Colors.white),
                            optionCont('ipad', Colors.white),
                            optionCont('Apple', Colors.white),
                            optionCont('ipad', Colors.white),
                          ],
                        ),
                      )
                    ],
                  )),
              buttoncont(
                  width,
                  'In flutter, Widget is a way to declare and construct UI. For example, row,column,container etc.',
                  Colors.purple[900])
            ],
          ),
        ),
      ),
    );
  }

  buttoncont(
    double width,
    String text,
    Color bgcolor,
  ) {
    return Container(
      margin: EdgeInsets.only(top: 20),
      padding: EdgeInsets.all(15),
      alignment: Alignment.center,
      height: 100,
      width: width,
      decoration: BoxDecoration(
          color: bgcolor, borderRadius: BorderRadius.circular(20)),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            height: 20,
            width: 20,
            decoration:
                BoxDecoration(shape: BoxShape.circle, color: Colors.white),
          ),
          Container(
            
            width: 300,
            child: Text(
              '$text',
              style: TextStyle(color: Colors.white),
            ),
          )
        ],
      ),
    );
  }

  optionCont(String text, Color bgcolor) {
    return Container(
      margin: EdgeInsets.only(top: 10),
      alignment: Alignment.center,
      height: 40,
      width: 250,
      decoration: BoxDecoration(
          color: bgcolor,
          border: Border.all(color: Colors.black),
          borderRadius: BorderRadius.circular(20)),
      child: Text(
        '$text',
        style: TextStyle(fontSize: 12),
      ),
    );
  }

  textCont(String text, Color color, FontWeight fontw, double fonts) {
    return Container(
      margin: EdgeInsets.only(top:10),
      alignment: Alignment.center,
      child: Text(
        '$text',
        style: TextStyle(color: color, fontSize: fonts, fontWeight: fontw),
      ),
    );
  }

  uCont(IconData icon, String text, Color bgcolor, Color textcolor,
      Color iconcolor) {
    return Container(
        height: 35,
        width: 100,
        decoration: BoxDecoration(
            color: bgcolor, borderRadius: BorderRadius.circular(20)),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Container(
              child: Icon(
                icon,
                color: iconcolor,
              ),
            ),
            Container(
            
                child: Text(
              '$text',
              style: TextStyle(color: textcolor),
            ))
          ],
        ));
  }
}
